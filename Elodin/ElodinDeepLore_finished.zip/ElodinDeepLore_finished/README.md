# ElodinDeepLore

This repaired package contains two usable builds:

- `index.html` — landing page
- `atlas.html` — searchable lore atlas built from `data.js` + `app.js`
- `ElodinDeepLore.html` — reconstructed longform standalone dossier
- `The Name of Wind.pdf` — local bundled reference file

## Notes

- The atlas keeps `Canon`, `Secondary`, `Meta`, and `Theory` separated.
- Some claims in the longform dossier are intentionally labelled as theory or conjecture and should be treated that way.
- The standalone dossier was reconstructed from the incomplete HTML output plus the saved remainder in the Claude log.
